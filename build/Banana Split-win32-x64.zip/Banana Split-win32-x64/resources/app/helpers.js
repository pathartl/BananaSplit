'use strict';

function showLoading() {
	$('.loading .modal').modal('show');
}

function hideLoading() {
	$('.loading .modal').modal('hide');
}

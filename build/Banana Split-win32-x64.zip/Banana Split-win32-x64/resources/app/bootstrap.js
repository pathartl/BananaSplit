'use strict';

var bananaSplit = angular.module('bananaSplit', ['ngRoute']);